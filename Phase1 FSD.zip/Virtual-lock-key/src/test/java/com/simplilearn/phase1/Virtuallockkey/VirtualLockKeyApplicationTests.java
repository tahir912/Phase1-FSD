package com.simplilearn.phase1.Virtuallockkey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualLockKeyApplicationTests {

	@Test
	void contextLoads() {
	}

}
