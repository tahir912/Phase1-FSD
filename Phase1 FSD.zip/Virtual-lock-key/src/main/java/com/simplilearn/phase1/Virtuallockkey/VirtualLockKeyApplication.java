package com.simplilearn.phase1.Virtuallockkey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import static com.simplilearn.phase1.Virtuallockkey.Phase1Project.WELCOME_PROMPT;

@SpringBootApplication
public class VirtualLockKeyApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtualLockKeyApplication.class, args);
		System.out.println(WELCOME_PROMPT);
		Phase1Project menu = new Phase1Project();
		menu.showPrimaryMenu();
	}

}
